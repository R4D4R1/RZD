import cv2
import numpy as np
import os
import csv
from tqdm import tqdm

print(cv2.__version__)

# Задайте желаемое разрешение (ширину и высоту)
desired_width = 400
desired_height = 400

def resize_frame(frame):
    # Изменение размера кадра до желаемых размеров
    return cv2.resize(frame, (desired_width, desired_height))

def detect_phone_usage(video_path):
    cap = cv2.VideoCapture(video_path)
    frame_count = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    fps = cap.get(cv2.CAP_PROP_FPS)

    profile_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_profileface.xml')
    phone_cascade = cv2.CascadeClassifier('haarcascade_mobilephone.xml')

    violations_count = 0
    violations = []
    violation_start = None

    for i in tqdm(range(frame_count), desc="Processing frames"):
        ret, frame = cap.read()
        if not ret:
            break

        # Изменяем размер кадра
        frame = resize_frame(frame)

        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

        profiles = profile_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(30, 30))

        phone_detected = False

        for (x, y, w, h) in profiles:
            roi_gray = gray[y:y + h, x:x + w]
            roi_color = frame[y:y + h, x:x + w]

            phones = phone_cascade.detectMultiScale(roi_gray)

            if len(phones) > 0:
                phone_detected = True
                break

        if phone_detected:
            if violation_start is None:
                violation_start = i / fps
            violations_count += 1
        else:
            if violation_start is not None:
                violation_end = i / fps
                violations.append((violation_start, violation_end))
                violation_start = None

    cap.release()

    report = {
        'violations_count': violations_count,
        'violations': violations
    }

    return report

def process_videos_in_folder(folder_path):
    video_files = [f for f in os.listdir(folder_path) if f.endswith('.mp4')]

    csv_path = os.path.join(folder_path, 'report.csv')
    with open(csv_path, 'w', newline='') as csv_file:
        writer = csv.writer(csv_file)
        writer.writerow(['Видео', 'Количество нарушений', 'Начало нарушения', 'Конец нарушения'])

        for video_file in video_files:
            video_path = os.path.join(folder_path, video_file)

            report = detect_phone_usage(video_path)

            print("Видео:", video_file)
            print("Количество нарушений:", report['violations_count'])
            print("Время нарушений на временной шкале видеофайла:")
            for violation in report['violations']:
                start_time, end_time = violation
                print("Начало:", start_time, "сек,", "Конец:", end_time, "сек")
                writer.writerow([video_file, report['violations_count'], start_time, end_time])
            print()

    print("Результаты сохранены в файл:", csv_path)

folder_path = 'B:/AllShots/Withoutphone'
process_videos_in_folder(folder_path)
